<?php 
woocommerce_get_template( 'archive-product.php' );