We created a one click install dummy content, so in just one click you can replicate our demo website.

You can do it using the AA Backup Manager, simply follow the instructions from here : 

http://docs.aa-team.com/kingdom/documentation/how-to-install-dummy-data-using-aa-backup-manager/

